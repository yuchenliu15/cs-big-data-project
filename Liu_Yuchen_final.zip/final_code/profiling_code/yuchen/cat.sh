hdfs dfs -cat "${1}/output/part-r-00000"
