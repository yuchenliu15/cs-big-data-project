hdfs dfs -rm -r "${1}/output/"
