hdfs dfs -cat "${1}/${2}/output/part-r-00000"
